package com.example.automobile.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.automobile.entity.Product;
import com.example.automobile.entity.Services;
import com.example.automobile.exception.ResourceNotFoundException;
import com.example.automobile.repository.ServicesRepository;
import com.example.automobile.service.ServicesService;

@Service
public class ServicesServiceImpl implements ServicesService {

    @Autowired
    private ServicesRepository servicesRepository;

    @Override
    public Services addServices(Services newServices) {
        return servicesRepository.save(newServices);
    }

    @Override
    public List<Services> getAllServices() {
        return servicesRepository.findAll();
    }
  
    @Override
    public Services getServicesById(Long serviceId) {
       Services services;
       Optional<Services> s=servicesRepository.findById(serviceId);
       if(s.isPresent())
   	{
   		services=s.get();
   	}
   	else
   	{
   		throw new ResourceNotFoundException("Services","Id",serviceId);
   	}
	return services;
       
    }

    @Override
    public Services updateServices(Long serviceId, Services updatedServices) {
        Services existingServices = servicesRepository.findById(serviceId).orElse(null);
        if (existingServices != null) {
            existingServices.setDescription(updatedServices.getDescription());
            existingServices.setServiceName(updatedServices.getServiceName());
            // Update other fields if needed
            return servicesRepository.save(existingServices);
        }
        return null;
    }

    @Override
    public void deleteServicesById(Long serviceId) {
        servicesRepository.deleteById(serviceId);
    }

    @Override
    public void deleteAllServices() {
        servicesRepository.deleteAll();
    }

    @Override
    public boolean isServicesExists(Long serviceId) {
        return servicesRepository.existsById(serviceId);
    }
}

package com.example.automobile.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.automobile.entity.Product;

@Component
public interface ProductService {
	
    Product addProduct(Product newProduct);
 
    List<Product> getAllProducts();
    
    Product getProductById(Long productId);
    
    Product updateProduct(Long productId, Product updatedProduct);
    
    void deleteProductById(Long productId);
    
    void deleteAllProducts();
    
    boolean doesProductExist(Long productId);
	
	
}

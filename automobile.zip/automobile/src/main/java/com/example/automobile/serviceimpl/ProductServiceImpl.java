package com.example.automobile.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.automobile.entity.Admin;
import com.example.automobile.entity.Product;
import com.example.automobile.repository.ProductRepository;
import com.example.automobile.service.ProductService;
import com.example.automobile.service.StockService;
import com.example.automobile.entity.Stock;
import com.example.automobile.exception.ResourceNotFoundException;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private StockService stockService;

    
    @Override
    public Product addProduct(Product newProduct) {
    	if (newProduct != null) {
            return productRepository.save(newProduct);
        }
        return null;
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
   
    @Override
    public Product getProductById(Long productId) {
      Product product;
    	Optional<Product> p=productRepository.findById(productId);
    	if(p.isPresent())
    	{
    		product=p.get();
    	}
    	else
    	{
    		throw new ResourceNotFoundException("Product","Id",productId);
    	}
		return product;
      
    }

    @Override
    public Product updateProduct(Long productId, Product product) {
        if (!productRepository.existsById(productId)) {
            throw new ResourceNotFoundException("Product", "id", productId);
        }
        Product existingProduct = productRepository.findById(productId).orElse(null);
        if (existingProduct != null) {
            existingProduct.setProductName(product.getProductName());
            existingProduct.setDescription(product.getDescription());
            existingProduct.setModel(product.getModel());
            existingProduct.setCategoryName(product.getCategoryName());
            existingProduct.setImagePath(product.getImagePath());
            existingProduct.setPrice(product.getPrice());
            existingProduct.setTotalQuantity(product.getTotalQuantity());
          
            
            
            // Update stock quantity based on product total quantity
            Stock stock = existingProduct.getStock();
            if (stock != null) {
                stock.setQuantity(product.getTotalQuantity());
                stockService.updateStock(stock.getStockId(), stock);
            }
            return productRepository.save(existingProduct);
        }
        return null;
    }

    @Override
    public void deleteProductById(Long productId) {
    	if (productId != null) {
            productRepository.deleteById(productId);
        }
    }

    @Override
    public void deleteAllProducts() {
        productRepository.deleteAll();
    }

    @Override
    public boolean doesProductExist(Long productId) {
        return productId != null && productRepository.existsById(productId);
    }
}

package com.example.automobile.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.automobile.entity.Admin;
import com.example.automobile.service.AdminService;

@Controller
//@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

  //display list of employees
  	@GetMapping("/")
  	public String viewHomePage(Model model) {
  		model.addAttribute("adminList",adminService.getAllAdmins());
  		return "index";
  	}
    
    @PostMapping("/add")
    public ResponseEntity<Admin> addAdmin(@RequestBody Admin admin) {
        Admin addedAdmin = adminService.addAdmin(admin);
        return new ResponseEntity<>(addedAdmin, HttpStatus.CREATED);
    }

    @GetMapping("/showNewAdminForm")
    public String showNewAdminForm(Model model) {
        Admin admin = new Admin();
        model.addAttribute("admin", admin);
        return "new_admin";
    }

    @PostMapping("/saveAdmin")
    public String saveAdmin(@ModelAttribute("admin") Admin admin) {
        adminService.addAdmin(admin);
        return "redirect:/";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable("id") long id, Model model) {
        Admin admin = adminService.getAdminById(id);
        model.addAttribute("admin", admin);
        return "update_admin";
    }

    @PostMapping("/updateAdmin/{id}")
    public String updateAdmin(@PathVariable("id") long id, @ModelAttribute("admin") Admin admin) {
        adminService.updateAdmin(id, admin);
        return "redirect:/";
    }

    @GetMapping("/deleteAdmin/{id}")
    public String deleteAdmin(@PathVariable("id") long id) {
        adminService.deleteAdminById(id);
        return "redirect:/";
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<Admin> getAdmin(@PathVariable Long id) {
        Admin admin = adminService.getAdminById(id);
        if (admin != null) {
            return new ResponseEntity<>(admin, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<Admin>> getAllAdmins() {
        List<Admin> admin = adminService.getAllAdmins();
        return new ResponseEntity<>(admin, HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Admin> updateAdmin(@PathVariable Long id, @RequestBody Admin admin) {
        Admin updatedAdmin = adminService.updateAdmin(id, admin);
        if (updatedAdmin != null) {
            return new ResponseEntity<>(updatedAdmin, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteAdminById(@PathVariable Long id) {
        if (adminService.isAdminExists(id)) {
            adminService.deleteAdminById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/deleteAll")
    public ResponseEntity<Void> deleteAllAdmins() {
        adminService.deleteAllAdmin();
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

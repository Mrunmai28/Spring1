package com.example.automobile.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import com.example.automobile.entity.Stock;
import com.example.automobile.service.StockService;
@Controller
@RestController
//@RequestMapping("/stock")
public class StockController {

    @Autowired
    private StockService stockService;
    
    @GetMapping({"/stock"})
    public String viewStockPage(Model model) {
        model.addAttribute("stockList", stockService.getAllStocks());
        return "stock";
    }
    
    
    @PostMapping("/addStock")
    public ResponseEntity<Stock> addStock(@RequestBody Stock newStock) {
        Stock addedStock = stockService.addStock(newStock);
        return new ResponseEntity<>(addedStock, HttpStatus.CREATED);
    }


    @GetMapping("/showNewStockForm")
    public String showNewStockForm(Model model) {
        Stock stock = new Stock();
        model.addAttribute("stock", stock);
        return "new_stock";
    }

    @PostMapping("/saveStock")
    public String saveStock(@ModelAttribute("stock") Stock stock) {
        stockService.addStock(stock);
        return "redirect:/";
    }

    @GetMapping("showFormForStockUpdate/{id}")
    public String showFormForUpdate(@PathVariable("id") long id, Model model) {
        Stock stock = stockService.getStockById(id);
        model.addAttribute("stock", stock);
        return "/update_stock";
    }

    @PostMapping("/updateStock/{id}")
    public String updateStock(@PathVariable("id") long id, @ModelAttribute("stock") Stock stock) {
        stockService.updateStock(id, stock);
        return "redirect:/";
    }

    @GetMapping("/deleteStock/{id}")
    public String deleteStock(@PathVariable("id") long id) {
        stockService.deleteStockById(id);
        return "redirect:/";
    }

    @GetMapping("/getStock/{stockId}")
    public ResponseEntity<Stock> getStock(@PathVariable Long stockId) {
        Stock stock = stockService.getStockById(stockId);
        if (stock != null) {
            return new ResponseEntity<>(stock, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/getAllStocks")
    public ResponseEntity<List<Stock>> getAllStocks() {
        List<Stock> stock = stockService.getAllStocks();
        return new ResponseEntity<>(stock, HttpStatus.OK);
    }

    @PutMapping("/updateStock/{stockId}")
    public ResponseEntity<Stock> updateStock(@PathVariable Long stockId, @RequestBody Stock updatedStock) {
        Stock stock = stockService.updateStock(stockId, updatedStock);
        if (stock != null) {
            return new ResponseEntity<>(stock, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    
   

    @DeleteMapping("/deleteStock/{stockId}")
    public ResponseEntity<Void> deleteStockById(@PathVariable Long stockId) {
        if (stockService.isStockExists(stockId)) {
            stockService.deleteStockById(stockId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/deleteAllStocks")
    public ResponseEntity<Void> deleteAllStocks() {
        stockService.deleteAllStock();
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

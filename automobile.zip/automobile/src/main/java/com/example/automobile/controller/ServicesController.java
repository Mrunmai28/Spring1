package com.example.automobile.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import com.example.automobile.entity.Services;
import com.example.automobile.service.ServicesService;
@Controller
//@RestController
//@RequestMapping("/services")
public class ServicesController {

    @Autowired
    private ServicesService servicesService;
    
    @GetMapping({"/services"})
    public String viewServicesPage(Model model) {
        model.addAttribute("servicesList", servicesService.getAllServices());
        return "/services";
    }
    
    @PostMapping("/addService")
    public ResponseEntity<Services> addServices(@RequestBody Services newServices) {
        Services addedServices = servicesService.addServices(newServices);
        return new ResponseEntity<>(addedServices, HttpStatus.CREATED);
    }


    @GetMapping("/showNewServiceForm")
    public String showNewServiceForm(Model model) {
        Services service = new Services();
        model.addAttribute("service", service);
        return "new_services";
    }

    @PostMapping("/saveService")
    public String saveService(@ModelAttribute("service") Services service) {
        servicesService.addServices(service);
        return "redirect:/";
    }

    @GetMapping("/showFormForServiceUpdate/{id}")
    public String showFormForUpdate(@PathVariable("id") long id, Model model) {
        Services service = servicesService.getServicesById(id);
        model.addAttribute("service", service);
        return "update_service";
    }

    @PostMapping("/updateService/{id}")
    public String updateService(@PathVariable("id") long id, @ModelAttribute("service") Services service) {
        servicesService.updateServices(id, service);
        return "redirect:/";
    }

    @GetMapping("/deleteService/{id}")
    public String deleteService(@PathVariable("id") long id) {
        servicesService.deleteServicesById(id);
        return "redirect:/";
    }

    @GetMapping("/getService/{serviceId}")
    public ResponseEntity<Services> getServices(@PathVariable Long serviceId) {
        Services services = servicesService.getServicesById(serviceId);
        if (services != null) {
            return new ResponseEntity<>(services, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/getAllServices")
    public ResponseEntity<List<Services>> getAllServices() {
        List<Services> services = servicesService.getAllServices();
        return new ResponseEntity<>(services, HttpStatus.OK);
    }

    @PutMapping("/updateService/{serviceId}")
    public ResponseEntity<Services> updateServices(@PathVariable Long serviceId, @RequestBody Services updatedServices) {
        Services updatedService = servicesService.updateServices(serviceId, updatedServices);
        if (updatedService != null) {
            return new ResponseEntity<>(updatedService, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/deleteService/{serviceId}")
    public ResponseEntity<Void> deleteServicesById(@PathVariable Long serviceId) {
        if (servicesService.isServicesExists(serviceId)) {
            servicesService.deleteServicesById(serviceId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/deleteAllServices")
    public ResponseEntity<Void> deleteAllServices() {
        servicesService.deleteAllServices();
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

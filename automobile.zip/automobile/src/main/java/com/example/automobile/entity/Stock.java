package com.example.automobile.entity;

import jakarta.persistence.*;

@Entity
@Table(name="stock")
public class Stock {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long stockId;
    
    @Column(nullable=false)
    private long quantity;
    
    @ManyToOne
    @JoinColumn(name="productId", referencedColumnName="productId",nullable = false)
    private Product product;
    
    @ManyToOne
    @JoinColumn(name = "adminId", referencedColumnName = "id", nullable = false)
    private Admin admin;

    public Stock() {
        super();
    }

	public Stock(long quantity) {
		super();
		this.quantity = quantity;
	}

	public long getStockId() {
		return stockId;
	}

	public void setStockId(long stockId) {
		this.stockId = stockId;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	

}
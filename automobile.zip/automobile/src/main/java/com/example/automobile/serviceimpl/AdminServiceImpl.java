package com.example.automobile.serviceimpl;

import com.example.automobile.entity.Admin;
import com.example.automobile.exception.ResourceNotFoundException;
import com.example.automobile.repository.AdminRepository;
import com.example.automobile.service.AdminService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public Admin addAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    @Override
    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }

    @Override
    public Admin getAdminById(Long id) {
    	Admin admin;
    	Optional<Admin> a=adminRepository.findById(id);
    	if(a.isPresent())
    	{
    	admin=a.get();
    	}
    	else
    	{
    		throw  new ResourceNotFoundException("Admin","id",id);
    	}
    	
        return admin;
    }

    @Override
    public Admin updateAdmin(Long id, Admin admin) {
        Admin existingAdmin = adminRepository.findById(id).orElse(null);
        if (existingAdmin != null) {
        	
            existingAdmin.setUserName(admin.getUserName());
            existingAdmin.setPassword(admin.getPassword());
          
            return adminRepository.save(existingAdmin);
        }
        return null;
    }

    @Override
    public void deleteAdminById(Long id) {
    	 if (id != null) {
             adminRepository.deleteById(id);
         }
    }

    @Override
    public void deleteAllAdmin() {
        adminRepository.deleteAll();
    }

    @Override
    public boolean isAdminExists(Long id) {
        return id != null && adminRepository.existsById(id);
    }
}

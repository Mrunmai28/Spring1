package com.example.automobile.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.automobile.entity.Admin;


@Component
public interface AdminService {

	
    Admin addAdmin(Admin admin);
	
	List<Admin> getAllAdmins();
	
	Admin getAdminById(Long id);
	
	Admin updateAdmin(Long id,Admin admin);
	
	void deleteAdminById(Long id);
	
	void deleteAllAdmin();
	
	boolean isAdminExists(Long id);
	
	
}

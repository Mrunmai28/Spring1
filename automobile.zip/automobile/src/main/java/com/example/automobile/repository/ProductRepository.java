package com.example.automobile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.automobile.entity.Product;

public interface ProductRepository extends JpaRepository<Product,Long>  {

}

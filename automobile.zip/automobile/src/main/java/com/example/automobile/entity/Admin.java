package com.example.automobile.entity;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name="admin")
public class Admin {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(nullable=false,length=50)
	private String userName;
	
	@Column(nullable=false,length=50)
	private String password;

  
//	@OneToMany(mappedBy="admin",cascade=CascadeType.ALL)
//	private List<Product> product;
//	
//	@OneToMany(mappedBy="admin",cascade=CascadeType.ALL)
//	private List<Services> service;
//	
//	@OneToMany(mappedBy="admin",cascade=CascadeType.ALL)
//	private List<Stock> stock;
//	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}


public Admin(long id, String userName, String password) {
	super();
	this.id = id;
	this.userName = userName;
	this.password = password;
}


public long getId() {
	return id;
}


public void setId(long id) {
	this.id = id;
}


public String getUserName() {
	return userName;
}


public void setUserName(String userName) {
	this.userName = userName;
}


public String getPassword() {
	return password;
}


public void setPassword(String password) {
	this.password = password;
}

}
	
	
//	public List<Product> getProducts() {
//		return products;
//	}
//
//	public void setProducts(List<Product> products) {
//		this.products = products;
//	}
//
//	public List<Services> getServices() {
//		return services;
//	}
//
//	public void setServices(List<Services> services) {
//		this.services = services;
//	}
//
//	
//	public List<Stock> getStocks() {
//		return stocks;
//	}
//
//	public void setStocks(List<Stock> stocks) {
//		this.stocks = stocks;
//	}
//	
	

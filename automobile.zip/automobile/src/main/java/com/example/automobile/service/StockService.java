package com.example.automobile.service;

import java.util.List;

import com.example.automobile.entity.Stock;

public interface StockService {

	 Stock addStock(Stock newStock);
	    
	    List<Stock> getAllStocks();
	    
	    Stock getStockById(Long stockId);
	    
	    Stock updateStock(Long stockId, Stock updatedStock);
	    
	    void deleteStockById(Long stockId);
	    
	    void deleteAllStock();
	    
	    boolean isStockExists(Long stockId);
}

package com.example.automobile.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.automobile.entity.Services;

@Component
public interface ServicesService {

	 Services addServices(Services newServices);
	    
	    List<Services> getAllServices();
	    
	    Services getServicesById(Long serviceId);
	    
	    Services updateServices(Long serviceId, Services updatedServices);
	    
	    void deleteServicesById(Long serviceId);
	    
	    void deleteAllServices();
	    
	    boolean isServicesExists(Long serviceId);
}

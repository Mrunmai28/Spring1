package com.example.automobile.entity;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name="product")
public class Product {
	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long productId;
	
	@Column(nullable=false,length=50,unique = true)
	private String productName;
	
	@Column(nullable=false)
	private String description;
	
	@Column(nullable=false,length=50)
	private String model;
	
	@Column(nullable=false,length=50)
	private String categoryName;
	
	@Column(nullable=false)
	private String imagePath;
	
	@Column(nullable=false)
	private double price;
	
	@Column(nullable=false)
	private long totalQuantity;
	
	@JsonIgnore
    @OneToOne(mappedBy="product", cascade=CascadeType.ALL)
    private Stock stock;
	
	
	@ManyToOne
	 @JoinColumn(name = "adminId", referencedColumnName = "id", nullable = false)
    private Admin admin;
	

	public Product() {
		super();
		
	}


	public Product(String productName, String description, String model, String categoryName, String imagePath,
			double price, long totalQuantity) {
		super();
		this.productName = productName;
		this.description = description;
		this.model = model;
		this.categoryName = categoryName;
		this.imagePath = imagePath;
		this.price = price;
		this.totalQuantity = totalQuantity;
		
	}


	public long getProductId() {
		return productId;
	}


	public void setProductId(long productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	public String getCategoryName() {
		return categoryName;
	}


	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	public String getImagePath() {
		return imagePath;
	}


	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public long getTotalQuantity() {
		return totalQuantity;
	}


	public void setTotalQuantity(long totalQuantity) {
		this.totalQuantity = totalQuantity;
	}


	public Stock getStock() {
		return stock;
	}


	public void setStock(Stock stock) {
		this.stock = stock;
	}


	public Admin getAdmin() {
		return admin;
	}


	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	
	
}

package com.example.automobile.entity;

import jakarta.persistence.*;

@Entity
@Table(name="services")
public class Services {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long serviceId;
	
	@Column(nullable=false)
	private String description;
	
	@Column(nullable=false,length=50)
	private String serviceName;
	
	
	@ManyToOne
	 @JoinColumn(name = "adminId", referencedColumnName = "id", nullable = false)
    private Admin admin;
	
	public Services() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Services(String description, String serviceName) {
		super();
		this.description = description;
		this.serviceName = serviceName;
		
		
	}

	public long getServiceId() {
		return serviceId;
	}

	public void setServiceId(long serviceId) {
		this.serviceId = serviceId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	

}
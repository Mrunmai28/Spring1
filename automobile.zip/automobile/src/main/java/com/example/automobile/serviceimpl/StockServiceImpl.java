package com.example.automobile.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.automobile.entity.Services;
import com.example.automobile.entity.Stock;
import com.example.automobile.exception.ResourceNotFoundException;
import com.example.automobile.repository.StockRepository;
import com.example.automobile.service.StockService;

@Service
public class StockServiceImpl implements StockService {

    @Autowired
    private StockRepository stockRepository;

    @Override
    public Stock addStock(Stock newStock) {
        return stockRepository.save(newStock);
    }

    @Override
    public List<Stock> getAllStocks() {
        return stockRepository.findAll();
    }

    @Override
    public Stock getStockById(Long stockId) {
    	       Stock stock;
    	       Optional<Stock> s=stockRepository.findById(stockId);
    	       if(s.isPresent())
    	   	{
    	   		stock=s.get();
    	   	}
    	   	else
    	   	{
    	   		throw new ResourceNotFoundException("Stock","Id",stockId);
    	   	}
    		return stock;
    	       
    	    }
    

    @Override
    public Stock updateStock(Long stockId, Stock updatedStock) {
        Stock existingStock = stockRepository.findById(stockId).orElse(null);
        if (existingStock != null) {
            existingStock.setQuantity(updatedStock.getQuantity());
            existingStock.setProduct(updatedStock.getProduct());
            existingStock.setAdmin(updatedStock.getAdmin());
            
            return stockRepository.save(existingStock);
        }
        return null;
    }

    @Override
    public void deleteStockById(Long stockId) {
        stockRepository.deleteById(stockId);
    }

    @Override
    public void deleteAllStock() {
        stockRepository.deleteAll();
    }

    @Override
    public boolean isStockExists(Long stockId) {
        return stockRepository.existsById(stockId);
    }
}

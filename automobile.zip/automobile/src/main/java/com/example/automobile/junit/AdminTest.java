package com.example.automobile.junit;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.automobile.entity.Admin;
import com.example.automobile.service.AdminService;

public class AdminTest {

   // private Admin admin;
    @Autowired
    AdminService adminService;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        System.out.println("Before Class");
    }

    @Before
    public void setUp() throws Exception {
       // admin = new Admin(); // Instantiate your Admin entity here
        System.out.println("Before Test");
    }
    @Test
    public void testInvalidAdmin() {
        // Set invalid properties of the admin entity
//        admin.setUserName(null);
//        admin.setPassword(null);
//
    	System.out.println(adminService.isAdminExists(1l));     // Test validation rules for invalid admin
       assertEquals(0,adminService.isAdminExists(1l));
      
    }

   

    // Add more test cases for Admin entity as needed

    @After
    public void tearDown() throws Exception {
        System.out.println("After Test");
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        System.out.println("After Class");
    }
}
